const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
    
    container_number:{
        type:String,
        require:true,
        min:3,
        max:20,
        unique:true
    },
       
    destination:{
        type:String,
        require:true,
        min:3,
        max:100
    },
    status:{
        type:Array,
        require:true,
        min:3,
        max:100
    },
       
    clients:{
        type:Array,
        require:false
    }, 
    shipment:{
        type:Array,
        require:false
    },
    date_shipped:{
        type:String
    }
    
    
},{timestamps:true})


module.exports=mongoose.model("containers", UserSchema)