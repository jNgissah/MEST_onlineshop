const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
    
    container_number:{
        type:String,
        require:true,
        min:3,
        max:20,
        unique:true
    },
       
    Destination:{
        type:String,
        require:true,
        min:3,
        max:20
    },
       
    clients:{
        type:Array,
        require:false
    }, 
    shipment:{
        type:Array,
        require:false
    }
    
    
},{timestamps:true})


module.exports=mongoose.model("containers", UserSchema)