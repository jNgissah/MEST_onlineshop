const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
    
    markID:{
        type:String,
        require:true,
        min:3,
        max:20,
        unique:true
    },
       
    firstname:{
        type:String,
        require:true,
        min:3,
        max:20
    },
       
    othername:{
        type:String,
        require:false,
        min:3,
        max:20
    }, 
    lastname:{
        type:String,
        require:true,
        min:3,
        max:20
    },
    contact:{
        type:String,
        require:true,
        min:3,
        max:50,
        unique:true
    },  
    address:{
        type:String,
        require:true,
        min:3,
        max:50

    },
    email:{
        type:String,
        require:false,
        min:3,
        max:50,
        unique:true
    },
    shipment:{
        type:Array
    },
    date:{
        type:String
       
     
    },
    time:{
        type:String
      
    }
    
    
    
},{timestamps:true})

module.exports=mongoose.model("users", UserSchema)